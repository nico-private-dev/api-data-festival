/**
 * Classe pour gérer la carte des festivals - Version WordPress
 */
class FestivalsMap {
    /**
     * Constructeur
     * @param {String} containerId - ID du conteneur de la carte
     * @param {Object} config - Configuration de la carte
     */
    constructor(containerId, config) {
        this.containerId = containerId;
        this.config = config.map;
        this.map = null;
        this.markers = [];
        this.markerClusterGroup = null;
        this.festivals = [];
        this.initMap();
    }
    
    /**
     * Initialise la carte
     */
    initMap() {
        // Création de la carte
        this.map = L.map(this.containerId, {
            center: this.config.center,
            zoom: this.config.zoom,
            minZoom: this.config.minZoom,
            maxZoom: this.config.maxZoom
        });
        
        // Ajout du fond de carte
        L.tileLayer(this.config.tileUrl, {
            attribution: this.config.attribution
        }).addTo(this.map);
        
        // Initialisation du groupe de clusters de marqueurs
        this.markerClusterGroup = L.markerClusterGroup({
            disableClusteringAtZoom: 10,
            spiderfyOnMaxZoom: true,
            showCoverageOnHover: false,
            zoomToBoundsOnClick: true
        });
        
        this.map.addLayer(this.markerClusterGroup);
    }
    
    /**
     * Crée un marqueur pour un festival
     * @param {Object} festival - Données du festival
     * @returns {Object} - Marqueur Leaflet
     */
    createMarker(festival) {
        // Vérification des coordonnées
        if (!festival.fields.coordonnees_insee || festival.fields.coordonnees_insee.length !== 2) {
            return null;
        }
        
        // Extraction des coordonnées
        const lat = festival.fields.coordonnees_insee[0];
        const lng = festival.fields.coordonnees_insee[1];
        
        // Vérification que les coordonnées sont dans une plage raisonnable pour la France
        if (lat < 41 || lat > 52 || lng < -5 || lng > 10) {
            return null;
        }
        
        // Création du marqueur
        const marker = L.marker([lat, lng]);
        
        // Ajout des données du festival au marqueur
        marker.festival = festival;
        
        // Ajout d'un popup
        marker.bindPopup(this.createPopupContent(festival));
        
        // Ajout d'un événement au clic
        marker.on('click', () => {
            if (typeof window.showFestivalDetails === 'function') {
                window.showFestivalDetails(festival);
            }
        });
        
        return marker;
    }
    
    /**
     * Crée le contenu du popup pour un festival
     * @param {Object} festival - Données du festival
     * @returns {String} - Contenu HTML du popup
     */
    createPopupContent(festival) {
        const fields = festival.fields;
        return `
            <div class="festival-popup">
                <h3>${fields.nom_du_festival || 'Festival sans nom'}</h3>
                <p>${fields.commune || ''} ${fields.departement || ''}</p>
                <p>${fields.periode_principale_de_deroulement_du_festival || ''}</p>
                <button onclick="showFestivalDetails(${JSON.stringify(festival).replace(/"/g, '&quot;')})">
                    Voir détails
                </button>
            </div>
        `;
    }
    
    /**
     * Affiche les festivals sur la carte
     * @param {Array} festivals - Liste des festivals à afficher
     */
    displayFestivals(festivals) {
        this.festivals = festivals;
        this.clearMarkers();
        
        const markers = festivals
            .map(festival => this.createMarker(festival))
            .filter(marker => marker !== null);
        
        this.markerClusterGroup.addLayers(markers);
        this.markers = markers;
        
        if (markers.length > 0) {
            const group = L.featureGroup(markers);
            const bounds = group.getBounds();
            
            // Vérification que les limites sont valides
            const franceBounds = L.latLngBounds(
                L.latLng(41.0, -5.5),
                L.latLng(51.5, 10.0)
            );
            
            if (franceBounds.contains(bounds) || bounds.getSouthWest().distanceTo(bounds.getNorthEast()) < 1000000) {
                this.map.fitBounds(bounds, { padding: [50, 50] });
            } else {
                // Si les limites sont trop grandes ou hors de France, on centre sur la France
                this.map.setView(this.config.center, this.config.zoom);
            }
        } else {
            // Si aucun marqueur valide, on centre sur la France
            this.map.setView(this.config.center, this.config.zoom);
        }
    }
    
    /**
     * Supprime tous les marqueurs de la carte
     */
    clearMarkers() {
        if (this.markerClusterGroup) {
            this.markerClusterGroup.clearLayers();
        }
        this.markers = [];
    }
    
    /**
     * Centre la carte sur un festival spécifique
     * @param {Object} festival - Festival à centrer
     */
    focusOnFestival(festival) {
        if (!festival || !festival.fields || !festival.fields.coordonnees_insee) {
            return;
        }
        
        const lat = festival.fields.coordonnees_insee[0];
        const lng = festival.fields.coordonnees_insee[1];
        
        // Vérification que les coordonnées sont valides
        if (lat < 41 || lat > 52 || lng < -5 || lng > 10) {
            return;
        }
        
        // Centrage de la carte
        this.map.setView([lat, lng], 13);
        
        // Recherche du marqueur correspondant
        const marker = this.markers.find(m => 
            m.festival && 
            m.festival.recordid === festival.recordid
        );
        
        // Ouverture du popup si le marqueur existe
        if (marker) {
            marker.openPopup();
        }
    }
    
    /**
     * Redimensionne la carte
     */
    resize() {
        if (this.map) {
            this.map.invalidateSize();
        }
    }
}
