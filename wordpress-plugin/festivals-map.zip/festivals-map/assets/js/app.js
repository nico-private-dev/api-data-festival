/**
 * Application principale pour la carte des festivals - Version WordPress
 */
document.addEventListener('DOMContentLoaded', function() {
    // Récupération des options passées par WordPress
    const options = window.festivalsMapOptions || {};
    
    // Initialisation des variables
    let api = null;
    let map = null;
    let festivals = [];
    let filteredFestivals = [];
    
    // Éléments DOM
    const mapContainer = document.getElementById('festivals-map');
    const festivalsContainer = document.getElementById('festivals-container');
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    const regionFilter = document.getElementById('region-filter');
    const departementFilter = document.getElementById('departement-filter');
    const moisFilter = document.getElementById('mois-filter');
    const genreFilter = document.getElementById('genre-filter');
    const festivalDetails = document.getElementById('festival-details');
    const overlay = document.getElementById('overlay');
    const closeButton = document.getElementById('close-button');
    const loadingContainer = document.getElementById('loading-container');
    const loadingCount = document.getElementById('loading-count');
    
    // Initialisation de l'application
    init();
    
    /**
     * Initialise l'application
     */
    function init() {
        // Vérification que le conteneur de carte existe
        if (!mapContainer) {
            console.error('Conteneur de carte non trouvé');
            return;
        }
        
        // Initialisation de l'API
        api = new FestivalsAPI(CONFIG);
        
        // Initialisation de la carte
        map = new FestivalsMap('festivals-map', CONFIG);
        
        // Chargement des festivals
        loadFestivals();
        
        // Ajout des écouteurs d'événements
        setupEventListeners();
        
        // Gestion du redimensionnement de la carte
        window.addEventListener('resize', function() {
            if (map) {
                map.resize();
            }
        });
    }
    
    /**
     * Affiche l'indicateur de chargement
     */
    function showLoading() {
        if (loadingContainer) {
            loadingContainer.style.display = 'flex';
        }
    }
    
    /**
     * Cache l'indicateur de chargement
     */
    function hideLoading() {
        if (loadingContainer) {
            loadingContainer.style.display = 'none';
        }
    }
    
    /**
     * Met à jour le compteur de chargement
     * @param {Number} count - Nombre de festivals chargés
     * @param {Number} total - Nombre total de festivals à charger
     */
    function updateLoadingCount(count, total) {
        if (loadingCount) {
            loadingCount.textContent = `${count} / ${total} festivals chargés`;
        }
    }
    
    /**
     * Charge les festivals depuis l'API
     */
    async function loadFestivals() {
        try {
            showLoading();
            updateLoadingCount(0, 'inconnu');
            
            // Récupération du nombre maximum de festivals à charger
            const maxFestivals = options.maxFestivals || 8000;
            
            // Appel à l'API
            const response = await api.getFestivals({ rows: maxFestivals });
            
            // Mise à jour du compteur
            updateLoadingCount(response.records.length, response.nhits);
            
            // Stockage des festivals
            festivals = response.records;
            filteredFestivals = festivals;
            
            // Affichage des festivals sur la carte
            map.displayFestivals(festivals);
            
            // Remplissage des filtres
            if (options.showFilters !== false) {
                populateFilters();
            }
            
            // Affichage des festivals dans la liste
            if (options.showList !== false) {
                displayFestivalsList(festivals);
            }
            
            // Cache l'indicateur de chargement
            hideLoading();
        } catch (error) {
            console.error('Erreur lors du chargement des festivals:', error);
            hideLoading();
            
            // Affichage d'un message d'erreur
            if (mapContainer) {
                mapContainer.innerHTML = `
                    <div class="error-message">
                        <h3>Erreur de chargement</h3>
                        <p>Impossible de charger les données des festivals. Veuillez réessayer ultérieurement.</p>
                        <p>Détail: ${error.message}</p>
                    </div>
                `;
            }
        }
    }
    
    /**
     * Remplit les filtres avec les valeurs disponibles
     */
    function populateFilters() {
        // Vérification que les filtres existent
        if (!regionFilter && !departementFilter && !moisFilter && !genreFilter) {
            return;
        }
        
        // Extraction des valeurs uniques
        const regions = api.extractUniqueValues(festivals, 'region');
        const departements = api.extractUniqueValues(festivals, 'departement');
        const mois = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 
                      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
        const genres = api.extractUniqueValues(festivals, 'discipline_dominante');
        
        // Remplissage des filtres
        populateFilter(regionFilter, regions);
        populateFilter(departementFilter, departements);
        populateFilter(moisFilter, mois);
        populateFilter(genreFilter, genres);
    }
    
    /**
     * Remplit un filtre avec des options
     * @param {HTMLElement} filter - Élément select à remplir
     * @param {Array} options - Options à ajouter
     */
    function populateFilter(filter, options) {
        if (!filter) return;
        
        // Ajout de l'option par défaut
        filter.innerHTML = '<option value="">Tous</option>';
        
        // Ajout des options
        options.forEach(option => {
            const optionElement = document.createElement('option');
            optionElement.value = option;
            optionElement.textContent = option;
            filter.appendChild(optionElement);
        });
    }
    
    /**
     * Affiche la liste des festivals
     * @param {Array} festivalsToDisplay - Festivals à afficher
     */
    function displayFestivalsList(festivalsToDisplay) {
        if (!festivalsContainer) return;
        
        // Vide le conteneur
        festivalsContainer.innerHTML = '';
        
        // Affichage des festivals
        festivalsToDisplay.forEach(festival => {
            const fields = festival.fields;
            
            // Création de la carte du festival
            const festivalCard = document.createElement('div');
            festivalCard.className = 'festival-card';
            festivalCard.innerHTML = `
                <h3>${fields.nom_du_festival || 'Festival sans nom'}</h3>
                <p><strong>Lieu:</strong> ${fields.commune || ''} (${fields.departement || ''})</p>
                <p><strong>Période:</strong> ${fields.periode_principale_de_deroulement_du_festival || 'Non précisée'}</p>
            `;
            
            // Ajout d'un événement au clic
            festivalCard.addEventListener('click', () => {
                showFestivalDetails(festival);
            });
            
            // Ajout au conteneur
            festivalsContainer.appendChild(festivalCard);
        });
    }
    
    /**
     * Affiche les détails d'un festival
     * @param {Object} festival - Festival à afficher
     */
    window.showFestivalDetails = function(festival) {
        if (!festivalDetails || !overlay) return;
        
        const fields = festival.fields;
        
        // Remplissage des détails
        festivalDetails.innerHTML = `
            <button id="close-button" class="close-button">&times;</button>
            <h2>${fields.nom_du_festival || 'Festival sans nom'}</h2>
            
            <div class="detail-group">
                <strong>Lieu:</strong> ${fields.commune || ''} (${fields.departement || ''}, ${fields.region || ''})
            </div>
            
            <div class="detail-group">
                <strong>Période:</strong> ${fields.periode_principale_de_deroulement_du_festival || 'Non précisée'}
            </div>
            
            <div class="detail-group">
                <strong>Discipline:</strong> ${fields.discipline_dominante || 'Non précisée'}
            </div>
            
            ${fields.site_web ? `
                <div class="detail-group">
                    <strong>Site web:</strong> <a href="${fields.site_web}" target="_blank">${fields.site_web}</a>
                </div>
            ` : ''}
            
            ${fields.adresse_mail ? `
                <div class="detail-group">
                    <strong>Contact:</strong> <a href="mailto:${fields.adresse_mail}">${fields.adresse_mail}</a>
                </div>
            ` : ''}
            
            ${fields.telephone ? `
                <div class="detail-group">
                    <strong>Téléphone:</strong> ${fields.telephone}
                </div>
            ` : ''}
            
            <button id="focus-on-map-btn" class="focus-on-map-btn">Centrer sur la carte</button>
        `;
        
        // Affichage des détails
        overlay.classList.add('active');
        festivalDetails.classList.add('active');
        
        // Ajout des écouteurs d'événements
        document.getElementById('close-button').addEventListener('click', closeFestivalDetails);
        document.getElementById('focus-on-map-btn').addEventListener('click', () => {
            closeFestivalDetails();
            map.focusOnFestival(festival);
        });
    };
    
    /**
     * Ferme les détails d'un festival
     */
    function closeFestivalDetails() {
        if (!festivalDetails || !overlay) return;
        
        overlay.classList.remove('active');
        festivalDetails.classList.remove('active');
    }
    
    /**
     * Configure les écouteurs d'événements
     */
    function setupEventListeners() {
        // Recherche
        if (searchButton && searchInput) {
            searchButton.addEventListener('click', () => {
                const query = searchInput.value.trim().toLowerCase();
                searchFestival(query);
            });
            
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    const query = searchInput.value.trim().toLowerCase();
                    searchFestival(query);
                }
            });
        }
        
        // Filtres
        const filters = [regionFilter, departementFilter, moisFilter, genreFilter];
        filters.forEach(filter => {
            if (filter) {
                filter.addEventListener('change', applyFilters);
            }
        });
        
        // Fermeture des détails
        if (overlay) {
            overlay.addEventListener('click', closeFestivalDetails);
        }
    }
    
    /**
     * Recherche un festival par nom
     * @param {String} query - Terme de recherche
     */
    function searchFestival(query) {
        if (!query) {
            // Si la recherche est vide, on affiche tous les festivals
            filteredFestivals = festivals;
            map.displayFestivals(filteredFestivals);
            if (options.showList !== false && festivalsContainer) {
                displayFestivalsList(filteredFestivals);
            }
            return;
        }
        
        // Recherche des festivals correspondants
        const results = festivals.filter(festival => {
            const fields = festival.fields;
            const name = fields.nom_du_festival ? fields.nom_du_festival.toLowerCase() : '';
            const commune = fields.commune ? fields.commune.toLowerCase() : '';
            
            return name.includes(query) || commune.includes(query);
        });
        
        // Mise à jour des festivals filtrés
        filteredFestivals = results;
        
        // Affichage des résultats
        map.displayFestivals(results);
        if (options.showList !== false && festivalsContainer) {
            displayFestivalsList(results);
        }
        
        // Message si aucun résultat
        if (results.length === 0 && festivalsContainer) {
            festivalsContainer.innerHTML = `
                <div class="no-results">
                    <p>Aucun festival ne correspond à votre recherche "${query}"</p>
                </div>
            `;
        }
    }
    
    /**
     * Applique les filtres sélectionnés
     */
    function applyFilters() {
        showLoading();
        updateLoadingCount(0, festivals.length);
        
        setTimeout(() => {
            // Récupération des valeurs des filtres
            const region = regionFilter ? regionFilter.value : '';
            const departement = departementFilter ? departementFilter.value : '';
            const mois = moisFilter ? moisFilter.value : '';
            const genre = genreFilter ? genreFilter.value : '';
            
            // Filtrage des festivals
            filteredFestivals = festivals.filter(festival => {
                const fields = festival.fields;
                
                // Filtre par région
                if (region && fields.region !== region) {
                    return false;
                }
                
                // Filtre par département
                if (departement && fields.departement !== departement) {
                    return false;
                }
                
                // Filtre par mois
                if (mois && fields.periode_principale_de_deroulement_du_festival) {
                    const periode = fields.periode_principale_de_deroulement_du_festival.toLowerCase();
                    if (!periode.includes(mois.toLowerCase())) {
                        return false;
                    }
                }
                
                // Filtre par genre
                if (genre && fields.discipline_dominante !== genre) {
                    return false;
                }
                
                return true;
            });
            
            // Mise à jour du compteur
            updateLoadingCount(filteredFestivals.length, festivals.length);
            
            // Affichage des festivals filtrés
            map.displayFestivals(filteredFestivals);
            if (options.showList !== false && festivalsContainer) {
                displayFestivalsList(filteredFestivals);
            }
            
            hideLoading();
        }, 100);
    }
});
