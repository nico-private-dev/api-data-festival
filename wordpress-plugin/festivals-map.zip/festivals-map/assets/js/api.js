/**
 * Classe pour gérer les appels à l'API des festivals - Version WordPress
 */
class FestivalsAPI {
    /**
     * Constructeur
     * @param {Object} config - Configuration de l'API
     */
    constructor(config) {
        this.config = config.api;
    }
    
    /**
     * Récupère les festivals depuis l'API
     * @param {Object} options - Options de la requête
     * @returns {Promise} - Promesse contenant les données des festivals
     */
    async getFestivals(options = {}) {
        try {
            // Construction de l'URL
            const url = new URL(this.config.baseUrl);
            
            // Paramètres de base
            const params = {
                dataset: this.config.dataset,
                ...this.config.defaultParams,
                ...options
            };
            
            // Ajout des paramètres à l'URL
            Object.keys(params).forEach(key => {
                url.searchParams.append(key, params[key]);
            });
            
            // Ajout des filtres
            if (this.config.refine) {
                Object.keys(this.config.refine).forEach(key => {
                    url.searchParams.append(`refine.${key}`, this.config.refine[key]);
                });
            }
            
            // Appel à l'API
            const response = await fetch(url);
            
            // Vérification de la réponse
            if (!response.ok) {
                throw new Error(`Erreur HTTP: ${response.status}`);
            }
            
            // Conversion de la réponse en JSON
            const data = await response.json();
            
            return data;
        } catch (error) {
            console.error('Erreur lors de la récupération des festivals:', error);
            throw error;
        }
    }
    
    /**
     * Extrait les valeurs uniques d'un champ dans un tableau d'objets
     * @param {Array} items - Tableau d'objets
     * @param {String} field - Nom du champ à extraire
     * @returns {Array} - Tableau des valeurs uniques
     */
    extractUniqueValues(items, field) {
        const values = items
            .map(item => item.fields[field])
            .filter(value => value !== undefined && value !== null && value !== '');
        
        // Gestion des tableaux (comme pour les genres musicaux)
        let flatValues = [];
        values.forEach(value => {
            if (Array.isArray(value)) {
                flatValues = [...flatValues, ...value];
            } else {
                flatValues.push(value);
            }
        });
        
        // Suppression des doublons et tri
        return [...new Set(flatValues)].sort();
    }
}
