/**
 * Configuration pour la carte des festivals - Version WordPress
 */
const CONFIG = {
    // Configuration de l'API
    api: {
        // URL de base de l'API
        baseUrl: 'https://data.culture.gouv.fr/api/records/1.0/search/',
        
        // Nom du dataset
        dataset: 'festivals-global-festivals-_-pl',
        
        // Paramètres par défaut
        defaultParams: {
            rows: 8000
        },
        
        // Filtres par défaut
        refine: {
            discipline_dominante: 'Musique'
        }
    },
    
    // Configuration de la carte
    map: {
        // Centre de la carte (centre de la France)
        center: [46.227638, 2.213749],
        
        // Niveau de zoom par défaut
        zoom: 6,
        
        // Niveau de zoom minimum
        minZoom: 2,
        
        // Niveau de zoom maximum
        maxZoom: 19,
        
        // URL du fond de carte
        tileUrl: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        
        // Attribution du fond de carte
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }
};
